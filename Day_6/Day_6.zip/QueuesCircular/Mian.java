package QueuesCircular;

public class Mian {
     public static void main(String[] args) {

     }
}
